import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { PageShell } from "@/components/site/PageShell";
import { ProductCard } from "@/components/site/ProductCard";
import { products } from "@/lib/products";
import { Heart, Truck, RotateCcw, Lock } from "lucide-react";

export const Route = createFileRoute("/product/$slug")({
  loader: ({ params }) => {
    const product = products.find((p) => p.slug === params.slug);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => ({
    meta: loaderData?.product
      ? [{ title: `${loaderData.product.name} — BeautyX` }, { name: "description", content: loaderData.product.description }]
      : [{ title: "Product — BeautyX" }],
  }),
  notFoundComponent: () => (
    <PageShell>
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <h1 className="font-serif text-4xl text-primary">Product not found</h1>
        <Link to="/" className="inline-block mt-6 underline text-primary">Back to home</Link>
      </div>
    </PageShell>
  ),
  component: ProductDetail,
});

function ProductDetail() {
  const { product: p } = Route.useLoaderData();
  const related = products.filter((x) => x.category === p.category && x.slug !== p.slug).slice(0, 4);
  return (
    <PageShell>
      <div className="mx-auto max-w-7xl px-4 py-10">
        <nav className="text-xs text-muted-foreground tracking-wider uppercase mb-8">
          <Link to="/" className="hover:text-primary">Home</Link> / <span className="text-primary">{p.name}</span>
        </nav>
        <div className="grid md:grid-cols-2 gap-12">
          <div className={`aspect-[4/5] rounded-sm bg-gradient-to-br ${p.bg} flex items-center justify-center text-primary-foreground/70 font-serif text-7xl`}>✦</div>
          <div>
            <h1 className="font-serif text-4xl text-primary">{p.name}</h1>
            <div className="mt-3 text-xl">
              {p.onSale && p.salePrice ? (
                <><span className="text-rose font-medium">PKR {p.salePrice.toLocaleString()}</span> <span className="line-through ml-2 text-muted-foreground text-base">PKR {p.price.toLocaleString()}</span></>
              ) : (<>PKR {p.price.toLocaleString()}</>)}
            </div>
            <p className="mt-6 text-muted-foreground leading-relaxed">{p.description}</p>
            <div className="mt-8">
              <div className="text-[11px] tracking-[0.25em] uppercase text-muted-foreground mb-3">Color</div>
              <div className="flex gap-3">
                {p.colors.map((c: string) => <button key={c} aria-label={c} className="h-7 w-7 rounded-full border border-border hover:ring-2 hover:ring-primary" style={{ backgroundColor: c }} />)}
              </div>
            </div>
            <div className="mt-6">
              <div className="text-[11px] tracking-[0.25em] uppercase text-muted-foreground mb-3">Size</div>
              <div className="flex gap-2 flex-wrap">
                {["XS", "S", "M", "L", "XL"].map((s) => <button key={s} className="h-10 w-12 border border-border text-sm hover:border-primary hover:text-primary">{s}</button>)}
              </div>
              <Link to="/size-guide" className="text-xs text-primary underline mt-3 inline-block">View size guide</Link>
            </div>
            <div className="mt-8 flex gap-3">
              <button className="flex-1 bg-primary text-primary-foreground py-3.5 text-[11px] tracking-[0.25em] uppercase hover:bg-primary/90">Add to Bag</button>
              <button aria-label="Wishlist" className="h-12 w-12 border border-border flex items-center justify-center hover:border-primary"><Heart className="h-4 w-4" /></button>
            </div>
            <dl className="mt-8 border-t border-border pt-6 text-sm space-y-2">
              <div className="flex justify-between"><dt className="text-muted-foreground">Fabric</dt><dd>{p.fabric}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Category</dt><dd className="capitalize">{p.category}</dd></div>
            </dl>
            <div className="mt-6 grid grid-cols-3 gap-3 text-xs text-muted-foreground">
              <div className="flex items-center gap-2"><Truck className="h-4 w-4 text-primary" />Fast delivery</div>
              <div className="flex items-center gap-2"><RotateCcw className="h-4 w-4 text-primary" />7-day returns</div>
              <div className="flex items-center gap-2"><Lock className="h-4 w-4 text-primary" />Secure checkout</div>
            </div>
          </div>
        </div>

        {related.length > 0 && (
          <section className="mt-24">
            <h2 className="font-serif text-2xl text-primary text-center">You may also like</h2>
            <div className="h-px w-12 bg-rose mx-auto mt-3 mb-10" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {related.map((r) => <ProductCard key={r.slug} p={r} />)}
            </div>
          </section>
        )}
      </div>
    </PageShell>
  );
}
