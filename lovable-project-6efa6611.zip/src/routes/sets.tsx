import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/site/PageShell";
import { getProductsByCategory } from "@/lib/products";

export const Route = createFileRoute("/sets")({
  head: () => ({ meta: [{ title: "Sets — BeautyX" }, { name: "description", content: "Matching lingerie sets designed to make you feel beautiful." }] }),
  component: () => <CategoryPage title="Sets" subtitle="Matching pieces, perfectly coordinated." products={getProductsByCategory("sets")} />,
});
