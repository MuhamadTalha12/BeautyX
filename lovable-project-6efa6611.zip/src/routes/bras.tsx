import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/site/PageShell";
import { getProductsByCategory } from "@/lib/products";

export const Route = createFileRoute("/bras")({
  head: () => ({ meta: [{ title: "Bras — BeautyX" }, { name: "description", content: "Bralettes, t-shirt bras, push-ups and more — premium fit & comfort." }] }),
  component: () => <CategoryPage title="Bras" subtitle="From everyday t-shirt bras to delicate bralettes — find your perfect fit." products={getProductsByCategory("bras")} />,
});
