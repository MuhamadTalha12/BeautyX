import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/site/PageShell";

export const Route = createFileRoute("/account")({
  head: () => ({ meta: [{ title: "Account — BeautyX" }] }),
  component: () => (
    <PageShell>
      <PageHero title="My Account" />
      <div className="mx-auto max-w-md px-4 py-16">
        <form className="space-y-4">
          <div>
            <label className="text-xs tracking-widest uppercase text-muted-foreground">Email</label>
            <input type="email" className="w-full mt-2 border border-border bg-background px-4 py-3 text-sm focus:border-primary outline-none" placeholder="you@example.com" />
          </div>
          <div>
            <label className="text-xs tracking-widest uppercase text-muted-foreground">Password</label>
            <input type="password" className="w-full mt-2 border border-border bg-background px-4 py-3 text-sm focus:border-primary outline-none" placeholder="••••••••" />
          </div>
          <button className="w-full bg-primary text-primary-foreground py-3.5 text-[11px] tracking-[0.25em] uppercase hover:bg-primary/90">Sign In</button>
          <p className="text-center text-sm text-muted-foreground">New to BeautyX? <span className="text-primary underline cursor-pointer">Create an account</span></p>
        </form>
      </div>
    </PageShell>
  ),
});
