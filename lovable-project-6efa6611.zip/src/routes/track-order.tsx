import { createFileRoute } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/site/PageShell";

export const Route = createFileRoute("/track-order")({
  head: () => ({ meta: [{ title: "Track Order — BeautyX" }] }),
  component: () => (
    <PageShell>
      <PageHero title="Track Your Order" subtitle="Enter your order number and email to see the latest status." />
      <div className="mx-auto max-w-md px-4 py-16">
        <form className="space-y-4">
          <input className="w-full border border-border bg-background px-4 py-3 text-sm focus:border-primary outline-none" placeholder="Order number (e.g. BX-12345)" />
          <input type="email" className="w-full border border-border bg-background px-4 py-3 text-sm focus:border-primary outline-none" placeholder="Email address" />
          <button className="w-full bg-primary text-primary-foreground py-3.5 text-[11px] tracking-[0.25em] uppercase hover:bg-primary/90">Track Order</button>
        </form>
      </div>
    </PageShell>
  ),
});
