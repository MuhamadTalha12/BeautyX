import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/site/PageShell";
import { getProductsByCategory } from "@/lib/products";

export const Route = createFileRoute("/shapewear")({
  head: () => ({ meta: [{ title: "Shapewear — BeautyX" }, { name: "description", content: "Smoothing shapewear that sculpts without squeezing." }] }),
  component: () => <CategoryPage title="Shapewear" subtitle="Smooth, sculpt and feel confident — without compromise." products={getProductsByCategory("shapewear")} />,
});
