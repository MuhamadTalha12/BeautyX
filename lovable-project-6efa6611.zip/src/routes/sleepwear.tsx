import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/site/PageShell";
import { getProductsByCategory } from "@/lib/products";

export const Route = createFileRoute("/sleepwear")({
  head: () => ({ meta: [{ title: "Sleepwear — BeautyX" }, { name: "description", content: "Silk robes and satin pajamas for your softest moments." }] }),
  component: () => <CategoryPage title="Sleepwear" subtitle="Silk, satin and softness — your weekend morning, elevated." products={getProductsByCategory("sleepwear")} />,
});
