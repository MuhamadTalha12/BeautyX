import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell, PageHero } from "@/components/site/PageShell";
import { ShoppingBag } from "lucide-react";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [{ title: "Your Bag — BeautyX" }] }),
  component: () => (
    <PageShell>
      <PageHero title="Your Bag" />
      <div className="mx-auto max-w-2xl px-4 py-20 text-center">
        <ShoppingBag className="h-12 w-12 text-primary mx-auto" />
        <h2 className="font-serif text-2xl text-primary mt-6">Your bag is empty</h2>
        <p className="text-muted-foreground mt-2">Discover our latest arrivals and best sellers.</p>
        <Link to="/new-arrivals" className="inline-block mt-8 bg-primary text-primary-foreground px-10 py-3.5 text-[11px] tracking-[0.25em] uppercase hover:bg-primary/90">Continue Shopping</Link>
      </div>
    </PageShell>
  ),
});
