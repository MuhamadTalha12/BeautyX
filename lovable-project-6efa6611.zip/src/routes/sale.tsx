import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/site/PageShell";
import { getProductsByCategory } from "@/lib/products";

export const Route = createFileRoute("/sale")({
  head: () => ({ meta: [{ title: "Sale — BeautyX" }, { name: "description", content: "Limited-time savings on selected lingerie & intimates." }] }),
  component: () => <CategoryPage title="Sale" subtitle="Loved pieces, lovely prices — for a limited time." products={getProductsByCategory("sale")} />,
});
