import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/site/PageShell";
import { getProductsByCategory } from "@/lib/products";

export const Route = createFileRoute("/new-arrivals")({
  head: () => ({ meta: [{ title: "New Arrivals — BeautyX" }, { name: "description", content: "The latest from BeautyX — fresh pieces just dropped." }] }),
  component: () => <CategoryPage title="New Arrivals" subtitle="Just landed — explore our newest pieces." products={getProductsByCategory("new-arrivals")} />,
});
