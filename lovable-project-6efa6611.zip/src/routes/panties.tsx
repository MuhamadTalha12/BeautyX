import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/site/PageShell";
import { getProductsByCategory } from "@/lib/products";

export const Route = createFileRoute("/panties")({
  head: () => ({ meta: [{ title: "Panties — BeautyX" }, { name: "description", content: "Briefs, thongs and everyday essentials in soft premium fabrics." }] }),
  component: () => <CategoryPage title="Panties" subtitle="Soft, seamless and made to move with you." products={getProductsByCategory("panties")} />,
});
