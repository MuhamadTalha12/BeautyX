import type { ReactNode } from "react";
import { Header } from "./Header";
import { Footer } from "./Footer";

export function PageShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

export function PageHero({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <section className="bg-secondary border-b border-border">
      <div className="mx-auto max-w-7xl px-4 py-14 text-center">
        <h1 className="font-serif text-4xl md:text-5xl text-primary">{title}</h1>
        {subtitle && <p className="mt-3 text-muted-foreground max-w-2xl mx-auto">{subtitle}</p>}
      </div>
    </section>
  );
}

export function CategoryPage({ title, subtitle, products }: { title: string; subtitle?: string; products: import("@/lib/products").Product[] }) {
  return (
    <PageShell>
      <PageHero title={title} subtitle={subtitle} />
      <section className="mx-auto max-w-7xl px-4 py-14">
        {products.length === 0 ? (
          <p className="text-center text-muted-foreground">No products in this category yet.</p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
            {products.map((p) => <ProductCardLazy key={p.slug} p={p} />)}
          </div>
        )}
      </section>
    </PageShell>
  );
}

import { ProductCard } from "./ProductCard";
function ProductCardLazy(props: { p: import("@/lib/products").Product }) { return <ProductCard {...props} />; }
