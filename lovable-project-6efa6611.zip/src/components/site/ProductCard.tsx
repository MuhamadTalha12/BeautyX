import { Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import type { Product } from "@/lib/products";

export function ProductCard({ p }: { p: Product }) {
  return (
    <div className="group">
      <Link to="/product/$slug" params={{ slug: p.slug }} className="block">
        <div className={`relative aspect-[4/5] rounded-sm overflow-hidden bg-gradient-to-br ${p.bg}`}>
          {p.isNew && (
            <span className="absolute top-3 left-3 bg-primary text-primary-foreground text-[10px] tracking-widest px-2 py-1">NEW</span>
          )}
          {p.onSale && (
            <span className="absolute top-3 left-3 bg-rose text-primary-foreground text-[10px] tracking-widest px-2 py-1">SALE</span>
          )}
          <div className="absolute inset-0 flex items-center justify-center font-serif text-primary-foreground/80 text-5xl opacity-60">✦</div>
        </div>
      </Link>
      <div className="pt-4 flex items-start justify-between">
        <div>
          <Link to="/product/$slug" params={{ slug: p.slug }} className="text-sm font-medium hover:text-primary">{p.name}</Link>
          <div className="text-sm text-muted-foreground mt-1">
            {p.onSale && p.salePrice ? (
              <><span className="text-rose font-medium">PKR {p.salePrice.toLocaleString()}</span> <span className="line-through ml-1 opacity-60">PKR {p.price.toLocaleString()}</span></>
            ) : (
              <>PKR {p.price.toLocaleString()}</>
            )}
          </div>
          <div className="flex gap-1.5 mt-2">
            {p.colors.map((c) => <span key={c} className="h-3 w-3 rounded-full border border-border" style={{ backgroundColor: c }} />)}
          </div>
        </div>
        <button aria-label="Wishlist" className="text-muted-foreground hover:text-rose"><Heart className="h-4 w-4" /></button>
      </div>
    </div>
  );
}
