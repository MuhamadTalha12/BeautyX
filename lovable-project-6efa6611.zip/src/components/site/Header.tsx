import { Link } from "@tanstack/react-router";
import { Search, User, ShoppingBag, Menu, X } from "lucide-react";
import { useState } from "react";

const nav = [
  { to: "/bras", label: "Bras" },
  { to: "/panties", label: "Panties" },
  { to: "/sets", label: "Sets" },
  { to: "/shapewear", label: "Shapewear" },
  { to: "/sleepwear", label: "Sleepwear" },
  { to: "/new-arrivals", label: "New Arrivals" },
  { to: "/sale", label: "Sale" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
      <div className="bg-primary text-primary-foreground text-[11px] tracking-wider">
        <div className="mx-auto max-w-7xl px-4 py-2 flex items-center justify-between">
          <span className="uppercase">Free Delivery on Orders Over PKR 3,000</span>
          <div className="hidden md:flex items-center gap-5">
            <Link to="/track-order" className="hover:opacity-80">Track Order</Link>
            <Link to="/help" className="hover:opacity-80">Help</Link>
            <span className="opacity-80">PKR</span>
          </div>
        </div>
      </div>
      <div className="mx-auto max-w-7xl px-4 h-20 flex items-center justify-between gap-6">
        <button className="md:hidden" onClick={() => setOpen(true)} aria-label="Menu">
          <Menu className="h-5 w-5" />
        </button>
        <Link to="/" className="flex flex-col items-center leading-none">
          <span className="font-serif text-3xl tracking-[0.25em] text-primary">BEAUTYX</span>
          <span className="text-[10px] tracking-[0.4em] text-muted-foreground mt-1">INTIMATES</span>
        </Link>
        <nav className="hidden md:flex items-center gap-7 text-[12px] tracking-widest uppercase">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className="text-foreground/80 hover:text-primary transition-colors"
              activeProps={{ className: "text-primary font-medium" }}>{n.label}</Link>
          ))}
        </nav>
        <div className="flex items-center gap-4">
          <button aria-label="Search" className="hover:text-primary"><Search className="h-5 w-5" /></button>
          <Link to="/account" aria-label="Account" className="hover:text-primary"><User className="h-5 w-5" /></Link>
          <Link to="/cart" aria-label="Cart" className="relative hover:text-primary">
            <ShoppingBag className="h-5 w-5" />
            <span className="absolute -top-2 -right-2 bg-rose text-primary-foreground text-[10px] rounded-full h-4 w-4 flex items-center justify-center">0</span>
          </Link>
        </div>
      </div>
      {open && (
        <div className="md:hidden fixed inset-0 z-50 bg-background">
          <div className="flex items-center justify-between p-4 border-b border-border">
            <span className="font-serif text-xl tracking-[0.25em] text-primary">BEAUTYX</span>
            <button onClick={() => setOpen(false)} aria-label="Close"><X className="h-5 w-5" /></button>
          </div>
          <nav className="flex flex-col p-6 gap-5 text-sm tracking-widest uppercase">
            {nav.map((n) => (
              <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="hover:text-primary">{n.label}</Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
